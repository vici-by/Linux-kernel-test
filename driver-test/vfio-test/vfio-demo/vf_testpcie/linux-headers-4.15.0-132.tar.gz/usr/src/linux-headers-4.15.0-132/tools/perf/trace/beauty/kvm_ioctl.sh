#!/bin/sh

kvm_header_dir=$1

printf "static const char *kvm_ioctl_cmds[] = {\n"
regex='^#[[:space:]]*define[[:space:]]+KVM_(\w+)[[:space:]]+_IO[RW]*\([[:space:]]*KVMIO[[:space:]]*,[[:space:]]*(0x[[:xdigit:]]+).*'
egrep $regex ${kvm_header_dir}/kvm.h	| \
	sed -r "s/$regex/\2 \1/g"	| \
	egrep -v " ((ARM|PPC|S390)_|[GS]ET_(DEBUGREGS|PIT2|XSAVE|TSC_KHZ)|CREATE_SPAPR_TCE_64)" | \
	sort | xargs printf "\t[%s] = \"%s\",\n"
printf "};\n"
