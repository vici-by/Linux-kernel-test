#define DTC_VERSION "DTC 1.4.5-gc1e55a55"
