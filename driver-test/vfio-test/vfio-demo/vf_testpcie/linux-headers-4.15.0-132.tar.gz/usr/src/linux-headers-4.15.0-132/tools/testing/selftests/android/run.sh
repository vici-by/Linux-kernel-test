#!/bin/sh

(cd ion; ./ion_test.sh)
