#!/bin/bash
# SPDX-License-Identifier: GPL-2.0
# Find device number in /sys/bus/usb/drivers/drivername
# Edit this file to update the driver numer and name
# Example test for uvcvideo driver
#i=0
# while :; do
#  i=$((i+1))
#  echo 1-5:1.0 > /sys/bus/usb/drivers/uvcvideo/unbind;
#  echo 1-5:1.0 > /sys/bus/usb/drivers/uvcvideo/bind;
#  clear
#	echo $i
#done
